/** Automatically generated file. DO NOT MODIFY */
package edu.cs.wisc.optitimal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}