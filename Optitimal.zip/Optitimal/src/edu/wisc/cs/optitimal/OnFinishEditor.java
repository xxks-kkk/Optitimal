package edu.wisc.cs.optitimal;

public interface OnFinishEditor {
    public void finishEditor();
}
