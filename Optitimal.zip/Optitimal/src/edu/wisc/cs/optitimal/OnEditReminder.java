package edu.wisc.cs.optitimal;

public interface OnEditReminder {
    public void editReminder(long id);
}
